import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, Edit, Trash2, CheckCircle2 } from "lucide-react";

interface SavedBuildCardProps {
  id: string;
  name: string;
  totalCost: number;
  partsCount: number;
  compatibilityScore: number;
  createdDate: string;
  onView?: (id: string) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

export function SavedBuildCard({
  id,
  name,
  totalCost,
  partsCount,
  compatibilityScore,
  createdDate,
  onView,
  onEdit,
  onDelete,
}: SavedBuildCardProps) {
  return (
    <Card className="hover-elevate" data-testid={`card-build-${id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-lg font-semibold line-clamp-2">{name}</h3>
          <Badge variant={compatibilityScore >= 80 ? "default" : "secondary"}>
            {compatibilityScore}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-muted-foreground">Total Cost</div>
            <div className="text-xl font-bold text-primary">₱{totalCost.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Parts</div>
            <div className="text-xl font-bold">{partsCount}</div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <span className="text-muted-foreground">Created {createdDate}</span>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2 pt-0">
        <Button
          variant="outline"
          className="flex-1"
          onClick={() => {
            onView?.(id);
            console.log("View build:", id);
          }}
          data-testid={`button-view-${id}`}
        >
          <Eye className="mr-2 h-4 w-4" />
          View
        </Button>
        <Button
          variant="outline"
          className="flex-1"
          onClick={() => {
            onEdit?.(id);
            console.log("Edit build:", id);
          }}
          data-testid={`button-edit-${id}`}
        >
          <Edit className="mr-2 h-4 w-4" />
          Edit
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => {
            onDelete?.(id);
            console.log("Delete build:", id);
          }}
          data-testid={`button-delete-${id}`}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}
