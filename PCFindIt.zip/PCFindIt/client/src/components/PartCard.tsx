import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";

export interface PartCardProps {
  id: string;
  name: string;
  category: string;
  price: number;
  image?: string;
  store: string;
  specs: { label: string; value: string }[];
  onAddToBuild?: (id: string) => void;
}

export function PartCard({ id, name, category, price, image, store, specs, onAddToBuild }: PartCardProps) {
  const storeColors: Record<string, string> = {
    Lazada: "bg-orange-500",
    Shopee: "bg-orange-600",
    "PC Express": "bg-blue-600",
    EasyPC: "bg-green-600",
  };

  return (
    <Card className="overflow-hidden hover-elevate" data-testid={`card-part-${id}`}>
      <div className="aspect-video w-full overflow-hidden bg-muted">
        {image ? (
          <img src={image} alt={name} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center text-muted-foreground">
            {category}
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="mb-2 flex items-start justify-between gap-2">
          <h3 className="text-lg font-semibold leading-tight line-clamp-2">{name}</h3>
          <Badge variant="secondary" className="shrink-0">
            {category}
          </Badge>
        </div>
        <div className="mb-3 grid grid-cols-2 gap-2 text-sm">
          {specs.slice(0, 4).map((spec, idx) => (
            <div key={idx} className="flex flex-col">
              <span className="text-muted-foreground text-xs">{spec.label}</span>
              <span className="font-medium truncate">{spec.value}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold">₱{price.toLocaleString()}</div>
            <div className="flex items-center gap-2 mt-1">
              <div className={`h-2 w-2 rounded-full ${storeColors[store] || "bg-gray-500"}`} />
              <span className="text-xs text-muted-foreground">{store}</span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button
          className="w-full"
          onClick={() => {
            onAddToBuild?.(id);
            console.log("Added to build:", id);
          }}
          data-testid={`button-add-${id}`}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add to Build
        </Button>
      </CardFooter>
    </Card>
  );
}
