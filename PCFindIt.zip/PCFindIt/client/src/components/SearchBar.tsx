import { Search } from "lucide-react";
import { useState } from "react";

interface SearchBarProps {
  onSearch?: (query: string) => void;
  placeholder?: string;
  variant?: "hero" | "compact";
}

export function SearchBar({ onSearch, placeholder = "Ask me anything about PC building or search for parts...", variant = "hero" }: SearchBarProps) {
  const [query, setQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(query);
    console.log("Search query:", query);
  };

  if (variant === "compact") {
    return (
      <form onSubmit={handleSubmit} className="relative w-full">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={placeholder}
          className="h-10 w-full rounded-lg border border-input bg-background pl-10 pr-4 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          data-testid="input-search"
        />
      </form>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="relative w-full max-w-4xl">
      <Search className="absolute left-6 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
      <input
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder={placeholder}
        className="h-14 w-full rounded-2xl border border-input bg-background pl-14 pr-6 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        data-testid="input-search-hero"
      />
    </form>
  );
}
