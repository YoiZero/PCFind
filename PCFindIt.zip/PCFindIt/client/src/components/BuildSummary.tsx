import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Save, Share2, Trash2 } from "lucide-react";

interface BuildPart {
  id: string;
  category: string;
  name: string;
  price: number;
}

interface BuildSummaryProps {
  parts: BuildPart[];
  onSave?: () => void;
  onShare?: () => void;
  onRemovePart?: (id: string) => void;
}

export function BuildSummary({ parts, onSave, onShare, onRemovePart }: BuildSummaryProps) {
  const totalCost = parts.reduce((sum, part) => sum + part.price, 0);
  const compatibilityScore = parts.length > 0 ? 85 : 0;

  return (
    <Card data-testid="card-build-summary">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Build Summary</CardTitle>
          {compatibilityScore > 0 && (
            <Badge variant={compatibilityScore >= 80 ? "default" : "secondary"}>
              {compatibilityScore}% Compatible
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {parts.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No parts added yet. Start building your PC!
          </p>
        ) : (
          <>
            <div className="space-y-2">
              {parts.map((part) => (
                <div
                  key={part.id}
                  className="flex items-center gap-3 rounded-lg border border-border p-3"
                  data-testid={`build-part-${part.id}`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-muted-foreground">{part.category}</div>
                    <div className="font-medium truncate">{part.name}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-semibold">₱{part.price.toLocaleString()}</div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                      onClick={() => {
                        onRemovePart?.(part.id);
                        console.log("Removed part:", part.id);
                      }}
                      data-testid={`button-remove-${part.id}`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-border pt-3">
              <div className="flex items-center justify-between">
                <span className="text-lg font-semibold">Total Cost</span>
                <span className="text-2xl font-bold text-primary">
                  ₱{totalCost.toLocaleString()}
                </span>
              </div>
            </div>
          </>
        )}
      </CardContent>
      {parts.length > 0 && (
        <CardFooter className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => {
              onShare?.();
              console.log("Share build clicked");
            }}
            data-testid="button-share-build"
          >
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              onSave?.();
              console.log("Save build clicked");
            }}
            data-testid="button-save-build"
          >
            <Save className="mr-2 h-4 w-4" />
            Save Build
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
