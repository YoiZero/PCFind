import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertTriangle, XCircle, Info } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface CompatibilityIssue {
  type: "success" | "warning" | "error" | "info";
  message: string;
}

interface CompatibilityPanelProps {
  issues: CompatibilityIssue[];
  powerUsage?: number;
  powerSupply?: number;
}

export function CompatibilityPanel({ issues, powerUsage = 0, powerSupply = 0 }: CompatibilityPanelProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case "error":
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Info className="h-4 w-4 text-blue-600" />;
    }
  };

  const powerPercentage = powerSupply > 0 ? (powerUsage / powerSupply) * 100 : 0;
  const powerStatus = powerPercentage > 90 ? "error" : powerPercentage > 75 ? "warning" : "success";

  return (
    <Card className="sticky top-20" data-testid="panel-compatibility">
      <CardHeader>
        <CardTitle>Compatibility Check</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {powerSupply > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Power Usage</span>
              <span className="font-medium">
                {powerUsage}W / {powerSupply}W
              </span>
            </div>
            <Progress value={powerPercentage} className="h-2" />
            {powerStatus === "error" && (
              <p className="text-xs text-red-600">Warning: Power usage is very high!</p>
            )}
          </div>
        )}

        <div className="space-y-2">
          {issues.length === 0 ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Info className="h-4 w-4" />
              <span>Add parts to check compatibility</span>
            </div>
          ) : (
            issues.map((issue, idx) => (
              <div
                key={idx}
                className="flex items-start gap-2 rounded-lg border border-border p-3"
                data-testid={`compatibility-${issue.type}`}
              >
                {getIcon(issue.type)}
                <p className="text-sm flex-1">{issue.message}</p>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
