import { CategoryCard } from "../CategoryCard";
import { Cpu, HardDrive, MemoryStick, MonitorSpeaker, Fan, Box } from "lucide-react";

export default function CategoryCardExample() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 p-8">
      <CategoryCard
        icon={Cpu}
        title="CPU"
        description="Processors"
      />
      <CategoryCard
        icon={MonitorSpeaker}
        title="GPU"
        description="Graphics Cards"
      />
      <CategoryCard
        icon={MemoryStick}
        title="RAM"
        description="Memory"
      />
      <CategoryCard
        icon={HardDrive}
        title="Storage"
        description="SSD & HDD"
      />
      <CategoryCard
        icon={Fan}
        title="Cooling"
        description="Fans & AIO"
      />
      <CategoryCard
        icon={Box}
        title="Case"
        description="PC Cases"
      />
    </div>
  );
}
