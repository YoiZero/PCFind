import { PartCard } from "../PartCard";

export default function PartCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-8">
      <PartCard
        id="cpu-1"
        name="AMD Ryzen 9 7950X"
        category="CPU"
        price={32500}
        store="PC Express"
        specs={[
          { label: "Cores", value: "16" },
          { label: "Threads", value: "32" },
          { label: "Base Clock", value: "4.5 GHz" },
          { label: "Socket", value: "AM5" },
        ]}
      />
      <PartCard
        id="gpu-1"
        name="NVIDIA RTX 4080 Super"
        category="GPU"
        price={65000}
        store="Lazada"
        specs={[
          { label: "Memory", value: "16GB GDDR6X" },
          { label: "Boost Clock", value: "2.55 GHz" },
          { label: "TDP", value: "320W" },
          { label: "Interface", value: "PCIe 4.0" },
        ]}
      />
      <PartCard
        id="ram-1"
        name="Corsair Vengeance DDR5 32GB"
        category="RAM"
        price={8500}
        store="Shopee"
        specs={[
          { label: "Capacity", value: "32GB (2x16GB)" },
          { label: "Speed", value: "6000 MHz" },
          { label: "Type", value: "DDR5" },
          { label: "Latency", value: "CL36" },
        ]}
      />
    </div>
  );
}
