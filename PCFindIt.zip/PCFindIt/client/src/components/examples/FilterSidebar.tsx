import { FilterSidebar } from "../FilterSidebar";

export default function FilterSidebarExample() {
  return (
    <div className="max-w-sm p-8">
      <FilterSidebar />
    </div>
  );
}
