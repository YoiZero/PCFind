import { SavedBuildCard } from "../SavedBuildCard";

export default function SavedBuildCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-8">
      <SavedBuildCard
        id="build-1"
        name="Gaming PC Build 2024"
        totalCost={125000}
        partsCount={8}
        compatibilityScore={95}
        createdDate="2 days ago"
      />
      <SavedBuildCard
        id="build-2"
        name="Budget Workstation"
        totalCost={45000}
        partsCount={7}
        compatibilityScore={88}
        createdDate="1 week ago"
      />
      <SavedBuildCard
        id="build-3"
        name="Streaming Setup"
        totalCost={89000}
        partsCount={9}
        compatibilityScore={92}
        createdDate="3 weeks ago"
      />
    </div>
  );
}
