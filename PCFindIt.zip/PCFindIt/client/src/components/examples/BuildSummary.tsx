import { BuildSummary } from "../BuildSummary";

export default function BuildSummaryExample() {
  return (
    <div className="max-w-md p-8">
      <BuildSummary
        parts={[
          { id: "cpu-1", category: "CPU", name: "AMD Ryzen 9 7950X", price: 32500 },
          { id: "gpu-1", category: "GPU", name: "NVIDIA RTX 4080 Super", price: 65000 },
          { id: "ram-1", category: "RAM", name: "Corsair Vengeance DDR5 32GB", price: 8500 },
        ]}
      />
    </div>
  );
}
