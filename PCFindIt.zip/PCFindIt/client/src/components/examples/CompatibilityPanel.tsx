import { CompatibilityPanel } from "../CompatibilityPanel";

export default function CompatibilityPanelExample() {
  return (
    <div className="max-w-md p-8">
      <CompatibilityPanel
        issues={[
          { type: "success", message: "CPU and motherboard are compatible (Socket AM5)" },
          { type: "success", message: "RAM is compatible with motherboard (DDR5)" },
          { type: "warning", message: "GPU may require additional power connectors" },
          { type: "info", message: "Consider upgrading PSU for future expansion" },
        ]}
        powerUsage={450}
        powerSupply={650}
      />
    </div>
  );
}
