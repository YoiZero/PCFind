import { SearchBar } from "../SearchBar";

export default function SearchBarExample() {
  return (
    <div className="space-y-8 p-8">
      <div className="flex justify-center">
        <SearchBar variant="hero" />
      </div>
      <div className="max-w-md">
        <SearchBar variant="compact" placeholder="Search parts..." />
      </div>
    </div>
  );
}
