import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useEffect, useState } from "react";

interface FilterSidebarProps {
  filters?: {
    category: string;
    priceMin: number | undefined;
    priceMax: number | undefined;
    store: string;
  };
  onFilterChange?: (filters: {
    category: string;
    priceMin: number | undefined;
    priceMax: number | undefined;
    store: string;
  }) => void;
  onClose?: () => void;
}

export function FilterSidebar({ filters, onFilterChange, onClose }: FilterSidebarProps) {
  const [priceRange, setPriceRange] = useState([
    filters?.priceMin || 0,
    filters?.priceMax || 100000
  ]);

  // Sync local price range with parent filter changes
  useEffect(() => {
    setPriceRange([
      filters?.priceMin || 0,
      filters?.priceMax || 100000
    ]);
  }, [filters?.priceMin, filters?.priceMax]);

  const categories = [
    "CPU", "Motherboard", "GPU", "RAM", "Storage", "PSU", "Case", "Cooling"
  ];

  const stores = [
    "Lazada", "Shopee", "PC Express", "EasyPC"
  ];

  return (
    <Card data-testid="filter-sidebar">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle>Filters</CardTitle>
        {onClose && (
          <Button variant="ghost" size="icon" onClick={onClose} className="md:hidden">
            <X className="h-4 w-4" />
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <Label>Price Range</Label>
          <div className="space-y-2">
            <Slider
              value={priceRange}
              onValueChange={(value) => {
                setPriceRange(value);
                onFilterChange?.({
                  category: filters?.category || "",
                  priceMin: value[0],
                  priceMax: value[1],
                  store: filters?.store || "",
                });
              }}
              max={100000}
              step={1000}
              data-testid="slider-price"
            />
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>₱{priceRange[0].toLocaleString()}</span>
              <span>₱{priceRange[1].toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Category</Label>
          <div className="space-y-2">
            {categories.map((category) => (
              <div key={category} className="flex items-center space-x-2">
                <Checkbox
                  id={`cat-${category}`}
                  checked={filters?.category === category}
                  onCheckedChange={(checked) => {
                    onFilterChange?.({
                      category: checked ? category : "",
                      priceMin: filters?.priceMin,
                      priceMax: filters?.priceMax,
                      store: filters?.store || "",
                    });
                  }}
                  data-testid={`checkbox-category-${category.toLowerCase()}`}
                />
                <label
                  htmlFor={`cat-${category}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {category}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label>Store</Label>
          <div className="space-y-2">
            {stores.map((store) => (
              <div key={store} className="flex items-center space-x-2">
                <Checkbox
                  id={`store-${store}`}
                  checked={filters?.store === store}
                  onCheckedChange={(checked) => {
                    onFilterChange?.({
                      category: filters?.category || "",
                      priceMin: filters?.priceMin,
                      priceMax: filters?.priceMax,
                      store: checked ? store : "",
                    });
                  }}
                  data-testid={`checkbox-store-${store.toLowerCase().replace(' ', '-')}`}
                />
                <label
                  htmlFor={`store-${store}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {store}
                </label>
              </div>
            ))}
          </div>
        </div>

        <Button
          variant="outline"
          className="w-full"
          onClick={() => {
            setPriceRange([0, 100000]);
            onFilterChange?.({
              category: "",
              priceMin: undefined,
              priceMax: undefined,
              store: "",
            });
          }}
          data-testid="button-clear-filters"
        >
          Clear Filters
        </Button>
      </CardContent>
    </Card>
  );
}
