import { useQuery } from "@tanstack/react-query";
import { SavedBuildCard } from "@/components/SavedBuildCard";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Link } from "wouter";
import type { Build } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

export default function SavedBuilds() {
  const { data: builds = [], isLoading } = useQuery<Build[]>({
    queryKey: ["/api/builds"],
  });

  const displayBuilds = builds.map(build => ({
    id: build.id,
    name: build.name,
    totalCost: build.totalCost,
    partsCount: build.partIds.length,
    compatibilityScore: build.compatibilityScore,
    createdDate: formatDistanceToNow(new Date(build.createdAt), { addSuffix: true }),
  }));

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="mb-2 text-3xl font-bold">My Saved Builds</h1>
            <p className="text-muted-foreground">
              View and manage your PC build configurations
            </p>
          </div>
          <Link href="/builder">
            <Button data-testid="button-new-build">
              <Plus className="mr-2 h-4 w-4" />
              New Build
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-muted-foreground">Loading builds...</p>
          </div>
        ) : displayBuilds.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-4 text-muted-foreground">
              <p className="text-lg">You haven't saved any builds yet</p>
              <p className="mt-2">Start building your dream PC today!</p>
            </div>
            <Link href="/builder">
              <Button size="lg">
                <Plus className="mr-2 h-4 w-4" />
                Create Your First Build
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {displayBuilds.map((build) => (
              <SavedBuildCard key={build.id} {...build} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
