import { SearchBar } from "@/components/SearchBar";
import { CategoryCard } from "@/components/CategoryCard";
import { Cpu, MonitorSpeaker, MemoryStick, HardDrive, Fan, Box } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import heroImage from "@assets/generated_images/Gaming_PC_hero_showcase_1d5525d7.png";

export default function Home() {
  const categories = [
    { icon: Cpu, title: "CPU", description: "Processors" },
    { icon: MonitorSpeaker, title: "GPU", description: "Graphics Cards" },
    { icon: MemoryStick, title: "RAM", description: "Memory" },
    { icon: HardDrive, title: "Storage", description: "SSD & HDD" },
    { icon: Fan, title: "Cooling", description: "Fans & AIO" },
    { icon: Box, title: "Case", description: "PC Cases" },
  ];

  return (
    <div className="min-h-screen">
      <div className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-background" />
        
        <div className="relative z-10 mx-auto max-w-4xl px-4 text-center">
          <h1 className="mb-4 text-4xl font-bold text-white md:text-6xl" data-testid="text-hero-title">
            Find Your Perfect PC Parts
          </h1>
          <p className="mb-8 text-lg text-white/90 md:text-xl" data-testid="text-hero-subtitle">
            Your one-stop shop for PC building in the Philippines. Check compatibility, compare prices, and build with confidence.
          </p>
          <SearchBar />
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8 text-center">
          <h2 className="mb-2 text-3xl font-bold">Browse by Category</h2>
          <p className="text-muted-foreground">
            Find the components you need for your perfect build
          </p>
        </div>
        
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          {categories.map((category) => (
            <CategoryCard key={category.title} {...category} />
          ))}
        </div>
      </div>

      <div className="bg-muted/50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-2 text-3xl font-bold">How It Works</h2>
            <p className="text-muted-foreground">
              Building your PC is easy with PCFind
            </p>
          </div>
          
          <div className="grid gap-8 md:grid-cols-3">
            <div className="text-center">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary text-2xl font-bold text-primary-foreground">
                1
              </div>
              <h3 className="mb-2 text-xl font-semibold">Search & Browse</h3>
              <p className="text-muted-foreground">
                Find PC parts from top Philippine retailers all in one place
              </p>
            </div>
            
            <div className="text-center">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary text-2xl font-bold text-primary-foreground">
                2
              </div>
              <h3 className="mb-2 text-xl font-semibold">Check Compatibility</h3>
              <p className="text-muted-foreground">
                Our tool ensures all your parts work together perfectly
              </p>
            </div>
            
            <div className="text-center">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary text-2xl font-bold text-primary-foreground">
                3
              </div>
              <h3 className="mb-2 text-xl font-semibold">Save & Build</h3>
              <p className="text-muted-foreground">
                Save your build and purchase from your preferred store
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="mb-4 text-3xl font-bold">Ready to Build Your PC?</h2>
          <p className="mb-8 text-lg text-muted-foreground">
            Start by browsing parts or jump straight to our PC builder
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/browse">
              <Button size="lg" data-testid="button-browse-parts">
                Browse Parts
              </Button>
            </Link>
            <Link href="/builder">
              <Button size="lg" variant="outline" data-testid="button-start-building">
                Start Building
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
