import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import compatibilityDiagram from "@assets/generated_images/PC_component_compatibility_diagram_547d1236.png";

export default function Help() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="mb-2 text-3xl font-bold">Help & Tutorials</h1>
        <p className="mb-8 text-muted-foreground">
          Learn how to use PCFind and build your perfect PC
        </p>

        <div className="mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Understanding PC Component Compatibility</CardTitle>
            </CardHeader>
            <CardContent>
              <img
                src={compatibilityDiagram}
                alt="PC Component Compatibility Diagram"
                className="w-full rounded-lg mb-4"
              />
              <p className="text-muted-foreground">
                This diagram shows the key compatibility points between PC components. Make sure your CPU socket matches your motherboard, RAM type is supported, and your PSU has enough power for all components.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8">
          <h2 className="mb-4 text-2xl font-semibold">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger data-testid="faq-compatibility">
                How does the compatibility checker work?
              </AccordionTrigger>
              <AccordionContent>
                Our compatibility checker analyzes the specifications of each component you select. It verifies that your CPU socket matches the motherboard, RAM type is supported (DDR4/DDR5), power supply has sufficient wattage, and all physical dimensions fit your case. You'll receive real-time warnings if any incompatibilities are detected.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2">
              <AccordionTrigger data-testid="faq-pricing">
                How accurate are the prices?
              </AccordionTrigger>
              <AccordionContent>
                Prices are sourced from major Philippine retailers including Lazada, Shopee, PC Express, and EasyPC. We update our database regularly to ensure pricing accuracy. However, actual prices may vary slightly due to promotions or stock availability.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3">
              <AccordionTrigger data-testid="faq-build-save">
                Can I save multiple PC builds?
              </AccordionTrigger>
              <AccordionContent>
                Yes! You can save as many PC builds as you want. Each saved build includes all your selected components, total cost, and compatibility status. You can access your saved builds anytime from the "Saved Builds" page to view, edit, or share them.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4">
              <AccordionTrigger data-testid="faq-purchase">
                Can I purchase parts directly through PCFind?
              </AccordionTrigger>
              <AccordionContent>
                Currently, PCFind serves as a comparison and compatibility tool. When you find the parts you want, we provide direct links to the retailers where you can make your purchase. This ensures you get the best deals from trusted Philippine stores.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5">
              <AccordionTrigger data-testid="faq-beginner">
                I'm a complete beginner. Where should I start?
              </AccordionTrigger>
              <AccordionContent>
                Start by determining your budget and use case (gaming, work, content creation). Then use our PC Builder tool which guides you through selecting components step-by-step. Begin with the CPU and motherboard as these determine compatibility for other parts. Our compatibility checker will help ensure you make the right choices.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-6">
              <AccordionTrigger data-testid="faq-power">
                How do I know if my PSU has enough power?
              </AccordionTrigger>
              <AccordionContent>
                Our PC Builder automatically calculates your system's total power consumption based on your selected components. We recommend a PSU with at least 20% headroom above your calculated usage. For example, if your build uses 500W, choose a 650W PSU for safety and future upgrades.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>

        <div>
          <h2 className="mb-4 text-2xl font-semibold">Quick Tips</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">CPU & Motherboard</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Always check that your CPU socket type (AM5, LGA1700, etc.) matches your motherboard. This is the most critical compatibility requirement.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">RAM Compatibility</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Modern builds use either DDR4 or DDR5 RAM. Your motherboard will only support one type, so choose accordingly. Check the maximum supported speed as well.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">GPU Clearance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  High-end graphics cards can be quite large. Make sure your case has enough clearance and your PSU has the required PCIe power connectors.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Storage Options</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  NVMe M.2 SSDs are the fastest option for modern builds. Check your motherboard for M.2 slots and ensure compatibility with PCIe 3.0 or 4.0.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
