import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { PartCard } from "@/components/PartCard";
import { BuildSummary } from "@/components/BuildSummary";
import { CompatibilityPanel } from "@/components/CompatibilityPanel";
import { SearchBar } from "@/components/SearchBar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Part } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface BuildPart {
  id: string;
  category: string;
  name: string;
  price: number;
}

export default function PCBuilder() {
  const [buildParts, setBuildParts] = useState<BuildPart[]>([]);
  const [compatibility, setCompatibility] = useState<{
    score: number;
    issues: Array<{ type: string; message: string }>;
  } | null>(null);

  const { data: parts = [], isLoading } = useQuery<Part[]>({
    queryKey: ["/api/parts"],
  });

  const checkCompatibilityMutation = useMutation({
    mutationFn: async (partIds: string[]) => {
      return await apiRequest("POST", "/api/compatibility/check", { partIds });
    },
    onSuccess: (data: any) => {
      setCompatibility(data as { score: number; issues: Array<{ type: string; message: string }> });
    },
  });

  useEffect(() => {
    if (buildParts.length > 0) {
      checkCompatibilityMutation.mutate(buildParts.map(p => p.id));
    } else {
      setCompatibility(null);
    }
  }, [buildParts]);

  const partsByCategory = useMemo(() => {
    const grouped: Record<string, any[]> = {};
    parts.forEach(part => {
      if (!grouped[part.category]) {
        grouped[part.category] = [];
      }
      grouped[part.category].push({
        ...part,
        specs: Object.entries(part.specs).map(([label, value]) => ({
          label,
          value,
        })),
      });
    });
    return grouped;
  }, [parts]);

  const categories = ["CPU", "Motherboard", "RAM", "GPU", "Storage", "PSU", "Case", "Cooling"];

  const handleAddToBuild = (id: string) => {
    const part = parts.find(p => p.id === id);
    if (part && !buildParts.find(p => p.id === id)) {
      setBuildParts([...buildParts, {
        id: part.id,
        category: part.category,
        name: part.name,
        price: part.price,
      }]);
    }
  };

  const handleRemovePart = (id: string) => {
    setBuildParts(buildParts.filter(p => p.id !== id));
  };

  const totalPowerUsage = useMemo(() => {
    const partIds = buildParts.map(p => p.id);
    const selectedParts = parts.filter(p => partIds.includes(p.id));
    return selectedParts.reduce((sum, part) => sum + (part.compatibility.powerDraw || 0), 0);
  }, [buildParts, parts]);

  const powerSupply = useMemo(() => {
    const psu = parts.find(p => buildParts.some(bp => bp.id === p.id) && p.category === "PSU");
    return psu?.compatibility.wattage || 0;
  }, [buildParts, parts]);

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="mb-6 text-3xl font-bold">PC Builder</h1>

        <div className="mb-6">
          <SearchBar variant="compact" placeholder="Search for parts to add..." />
        </div>

        <div className="grid gap-6 lg:grid-cols-[1fr_350px]">
          <div className="space-y-6">
            <Tabs defaultValue="CPU" className="w-full">
              <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
                {categories.map((cat) => (
                  <TabsTrigger key={cat} value={cat} data-testid={`tab-${cat.toLowerCase()}`}>
                    {cat}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {categories.map((cat) => (
                <TabsContent key={cat} value={cat} className="mt-6">
                  {isLoading ? (
                    <div className="py-8 text-center text-muted-foreground">
                      Loading parts...
                    </div>
                  ) : partsByCategory[cat]?.length > 0 ? (
                    <div className="grid gap-6 md:grid-cols-2">
                      {partsByCategory[cat].map((part) => (
                        <PartCard
                          key={part.id}
                          {...part}
                          onAddToBuild={handleAddToBuild}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="py-8 text-center text-muted-foreground">
                      No {cat} parts available
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </div>

          <div className="space-y-6">
            <BuildSummary
              parts={buildParts}
              onRemovePart={handleRemovePart}
            />
            <CompatibilityPanel
              issues={compatibility?.issues.map(issue => ({
                ...issue,
                type: issue.type as "error" | "success" | "warning" | "info"
              })) || []}
              powerUsage={totalPowerUsage}
              powerSupply={powerSupply}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
