import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="mb-2 text-3xl font-bold">About PCFind</h1>
        <p className="mb-8 text-lg text-muted-foreground">
          Your trusted guide to PC building in the Philippines
        </p>

        <div className="prose prose-slate dark:prose-invert max-w-none mb-8">
          <p className="text-lg">
            In today's digital age, building a personal computer (PC) has become essential for gamers, students, professionals, and creative individuals. A custom-built PC offers better performance, value, and flexibility compared to pre-built systems. However, choosing compatible parts and finding affordable deals remains challenging.
          </p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">The Problem We Solve</h2>
          <p>
            For beginners, PC building can be overwhelming. You need to consider technical details like power supply compatibility, RAM specifications, processor support, and more. Even experienced builders face the hassle of browsing multiple local shops and comparing prices across various platforms.
          </p>

          <p>
            Popular online marketplaces like Lazada and Shopee allow purchasing PC components, but they lack two critical features: <strong>compatibility checking</strong> and <strong>specialized PC building guidance</strong>. This leaves users vulnerable to costly mistakes or relying solely on third-party forums.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Our Solution</h2>
          <p>
            PCFind addresses this gap by serving as both an online hub for PC parts and a virtual PC builder. We consolidate stocks and deals from local shops like PC Express and EasyPC, while helping users analyze their builds for compatibility and budget-friendliness.
          </p>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">What Makes PCFind Different</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold mb-1">Centralized Platform</h3>
                    <p className="text-sm text-muted-foreground">
                      Browse parts from multiple Philippine retailers in one place - no more tab hopping
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold mb-1">Real-Time Compatibility</h3>
                    <p className="text-sm text-muted-foreground">
                      Instant compatibility checking ensures all your parts work together perfectly
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold mb-1">Beginner-Friendly</h3>
                    <p className="text-sm text-muted-foreground">
                      Clean, intuitive interface designed for both beginners and experienced builders
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold mb-1">Philippine-Focused</h3>
                    <p className="text-sm text-muted-foreground">
                      Pricing and availability tailored specifically for the Philippine market
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <Card>
            <CardContent className="pt-6">
              <p className="text-lg">
                To make PC building accessible, affordable, and stress-free for everyone in the Philippines. We believe that building your own PC should be an exciting journey, not a frustrating challenge.
              </p>
            </CardContent>
          </Card>
        </div>

        <div>
          <h2 className="text-2xl font-semibold mb-4">Partner Stores</h2>
          <p className="text-muted-foreground mb-4">
            We work with trusted Philippine retailers to bring you the best selection and prices:
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {["Lazada", "Shopee", "PC Express", "EasyPC"].map((store) => (
              <Card key={store}>
                <CardContent className="pt-6">
                  <p className="text-center font-semibold">{store}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
