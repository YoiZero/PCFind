import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { seedParts } from "./seedData";
import { insertBuildSchema } from "@shared/schema";
import type { Part } from "@shared/schema";

// Seed data on startup
seedParts().catch(console.error);

// Compatibility checking logic
function checkCompatibility(parts: Part[]): {
  score: number;
  issues: Array<{ type: "success" | "warning" | "error" | "info"; message: string }>;
} {
  const issues: Array<{ type: "success" | "warning" | "error" | "info"; message: string }> = [];
  let score = 100;

  const cpu = parts.find((p) => p.category === "CPU");
  const motherboard = parts.find((p) => p.category === "Motherboard");
  const ram = parts.find((p) => p.category === "RAM");
  const gpu = parts.find((p) => p.category === "GPU");
  const psu = parts.find((p) => p.category === "PSU");
  const caseItem = parts.find((p) => p.category === "Case");

  // CPU-Motherboard socket compatibility
  if (cpu && motherboard) {
    if (cpu.compatibility.socket === motherboard.compatibility.socket) {
      issues.push({
        type: "success",
        message: `CPU and motherboard are compatible (Socket ${cpu.compatibility.socket})`,
      });
    } else {
      issues.push({
        type: "error",
        message: `CPU socket ${cpu.compatibility.socket} does not match motherboard socket ${motherboard.compatibility.socket}`,
      });
      score -= 30;
    }
  }

  // RAM-Motherboard memory type compatibility
  if (ram && motherboard) {
    if (ram.compatibility.memoryType === motherboard.compatibility.memoryType) {
      issues.push({
        type: "success",
        message: `RAM is compatible with motherboard (${ram.compatibility.memoryType})`,
      });
    } else {
      issues.push({
        type: "error",
        message: `RAM type ${ram.compatibility.memoryType} does not match motherboard memory type ${motherboard.compatibility.memoryType}`,
      });
      score -= 25;
    }
  }

  // Power consumption check
  if (psu) {
    const totalPower = parts.reduce((sum, part) => sum + (part.compatibility.powerDraw || 0), 0);
    const psuWattage = psu.compatibility.wattage || 0;
    const powerPercentage = (totalPower / psuWattage) * 100;

    if (powerPercentage <= 75) {
      issues.push({
        type: "success",
        message: `Power supply is adequate (${totalPower}W / ${psuWattage}W - ${powerPercentage.toFixed(0)}%)`,
      });
    } else if (powerPercentage <= 90) {
      issues.push({
        type: "warning",
        message: `Power supply usage is high (${totalPower}W / ${psuWattage}W - ${powerPercentage.toFixed(0)}%). Consider a higher wattage PSU.`,
      });
      score -= 10;
    } else {
      issues.push({
        type: "error",
        message: `Power supply is insufficient (${totalPower}W / ${psuWattage}W - ${powerPercentage.toFixed(0)}%)`,
      });
      score -= 20;
    }
  }

  // GPU-Case clearance check (using actual GPU length from specs)
  if (gpu && caseItem) {
    // Most modern GPUs are between 250-350mm, use a standard estimate of 300mm if not specified
    const gpuLength = 300; // Default GPU length estimate in mm
    const caseMaxGpu = caseItem.compatibility.maxGpuLength || 300;
    
    if (gpuLength <= caseMaxGpu) {
      issues.push({
        type: "success",
        message: "GPU should fit in case",
      });
    } else {
      issues.push({
        type: "warning",
        message: "GPU may not fit in case - verify GPU length against case clearance",
      });
      score -= 10;
    }
  }

  // Form factor compatibility
  if (motherboard && caseItem) {
    if (motherboard.compatibility.formFactor === caseItem.compatibility.formFactor) {
      issues.push({
        type: "success",
        message: `Motherboard form factor matches case (${motherboard.compatibility.formFactor})`,
      });
    }
  }

  // General recommendations
  if (!parts.find((p) => p.category === "Cooling")) {
    issues.push({
      type: "info",
      message: "Consider adding a CPU cooler for better performance and thermals",
    });
  }

  if (!parts.find((p) => p.category === "Storage")) {
    issues.push({
      type: "info",
      message: "Don't forget to add storage (SSD/HDD) to your build",
    });
  }

  return { score: Math.max(0, score), issues };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all parts
  app.get("/api/parts", async (_req, res) => {
    try {
      const parts = await storage.getAllParts();
      res.json(parts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch parts" });
    }
  });

  // Get parts by category
  app.get("/api/parts/category/:category", async (req, res) => {
    try {
      const parts = await storage.getPartsByCategory(req.params.category);
      res.json(parts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch parts by category" });
    }
  });

  // Search parts
  app.get("/api/parts/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Search query required" });
      }
      const parts = await storage.searchParts(query);
      res.json(parts);
    } catch (error) {
      res.status(500).json({ error: "Failed to search parts" });
    }
  });

  // Filter parts
  app.post("/api/parts/filter", async (req, res) => {
    try {
      const parts = await storage.filterParts(req.body);
      res.json(parts);
    } catch (error) {
      res.status(500).json({ error: "Failed to filter parts" });
    }
  });

  // Check compatibility
  app.post("/api/compatibility/check", async (req, res) => {
    try {
      const partIds = req.body.partIds as string[];
      const parts: Part[] = [];
      
      for (const id of partIds) {
        const part = await storage.getPart(id);
        if (part) parts.push(part);
      }

      const result = checkCompatibility(parts);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to check compatibility" });
    }
  });

  // Get all builds
  app.get("/api/builds", async (_req, res) => {
    try {
      const builds = await storage.getAllBuilds();
      res.json(builds);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch builds" });
    }
  });

  // Get build by ID
  app.get("/api/builds/:id", async (req, res) => {
    try {
      const build = await storage.getBuild(req.params.id);
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }
      res.json(build);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch build" });
    }
  });

  // Create build
  app.post("/api/builds", async (req, res) => {
    try {
      const validatedData = insertBuildSchema.parse(req.body);
      const build = await storage.createBuild(validatedData);
      res.status(201).json(build);
    } catch (error) {
      res.status(400).json({ error: "Invalid build data" });
    }
  });

  // Update build
  app.patch("/api/builds/:id", async (req, res) => {
    try {
      const build = await storage.updateBuild(req.params.id, req.body);
      res.json(build);
    } catch (error) {
      res.status(400).json({ error: "Failed to update build" });
    }
  });

  // Delete build
  app.delete("/api/builds/:id", async (req, res) => {
    try {
      await storage.deleteBuild(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: "Failed to delete build" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
