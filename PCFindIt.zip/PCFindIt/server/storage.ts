import { type Part, type InsertPart, type Build, type InsertBuild } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Parts operations
  getPart(id: string): Promise<Part | undefined>;
  getAllParts(): Promise<Part[]>;
  getPartsByCategory(category: string): Promise<Part[]>;
  searchParts(query: string): Promise<Part[]>;
  filterParts(filters: {
    category?: string;
    priceMin?: number;
    priceMax?: number;
    store?: string;
  }): Promise<Part[]>;
  
  // Builds operations
  getBuild(id: string): Promise<Build | undefined>;
  getAllBuilds(): Promise<Build[]>;
  createBuild(build: InsertBuild): Promise<Build>;
  updateBuild(id: string, build: Partial<InsertBuild>): Promise<Build>;
  deleteBuild(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private parts: Map<string, Part>;
  private builds: Map<string, Build>;

  constructor() {
    this.parts = new Map();
    this.builds = new Map();
  }

  // Parts operations
  async getPart(id: string): Promise<Part | undefined> {
    return this.parts.get(id);
  }

  async getAllParts(): Promise<Part[]> {
    return Array.from(this.parts.values());
  }

  async getPartsByCategory(category: string): Promise<Part[]> {
    return Array.from(this.parts.values()).filter(
      (part) => part.category.toLowerCase() === category.toLowerCase()
    );
  }

  async searchParts(query: string): Promise<Part[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.parts.values()).filter(
      (part) =>
        part.name.toLowerCase().includes(lowerQuery) ||
        part.category.toLowerCase().includes(lowerQuery) ||
        part.store.toLowerCase().includes(lowerQuery)
    );
  }

  async filterParts(filters: {
    category?: string;
    priceMin?: number;
    priceMax?: number;
    store?: string;
  }): Promise<Part[]> {
    let results = Array.from(this.parts.values());

    if (filters.category) {
      results = results.filter(
        (part) => part.category.toLowerCase() === filters.category!.toLowerCase()
      );
    }

    if (filters.priceMin !== undefined) {
      results = results.filter((part) => part.price >= filters.priceMin!);
    }

    if (filters.priceMax !== undefined) {
      results = results.filter((part) => part.price <= filters.priceMax!);
    }

    if (filters.store) {
      results = results.filter(
        (part) => part.store.toLowerCase() === filters.store!.toLowerCase()
      );
    }

    return results;
  }

  // Builds operations
  async getBuild(id: string): Promise<Build | undefined> {
    return this.builds.get(id);
  }

  async getAllBuilds(): Promise<Build[]> {
    return Array.from(this.builds.values());
  }

  async createBuild(insertBuild: InsertBuild): Promise<Build> {
    const id = randomUUID();
    const build: Build = {
      ...insertBuild,
      id,
      createdAt: new Date(),
    };
    this.builds.set(id, build);
    return build;
  }

  async updateBuild(id: string, updates: Partial<InsertBuild>): Promise<Build> {
    const existing = this.builds.get(id);
    if (!existing) {
      throw new Error("Build not found");
    }
    const updated = { ...existing, ...updates };
    this.builds.set(id, updated);
    return updated;
  }

  async deleteBuild(id: string): Promise<void> {
    this.builds.delete(id);
  }
}

export const storage = new MemStorage();
