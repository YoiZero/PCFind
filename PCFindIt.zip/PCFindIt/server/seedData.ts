import { storage } from "./storage";
import type { Part } from "@shared/schema";

export async function seedParts() {
  const parts: Omit<Part, "id">[] = [
    // CPUs
    {
      name: "AMD Ryzen 9 7950X",
      category: "CPU",
      price: 32500,
      store: "PC Express",
      image: null,
      specs: {
        Cores: "16",
        Threads: "32",
        "Base Clock": "4.5 GHz",
        "Boost Clock": "5.7 GHz",
        TDP: "170W",
      },
      compatibility: {
        socket: "AM5",
        powerDraw: 170,
      },
    },
    {
      name: "Intel Core i9-14900K",
      category: "CPU",
      price: 38000,
      store: "EasyPC",
      image: null,
      specs: {
        Cores: "24",
        Threads: "32",
        "Base Clock": "3.2 GHz",
        "Boost Clock": "6.0 GHz",
        TDP: "125W",
      },
      compatibility: {
        socket: "LGA1700",
        powerDraw: 253,
      },
    },
    {
      name: "AMD Ryzen 7 7800X3D",
      category: "CPU",
      price: 25000,
      store: "Lazada",
      image: null,
      specs: {
        Cores: "8",
        Threads: "16",
        "Base Clock": "4.2 GHz",
        "Boost Clock": "5.0 GHz",
        TDP: "120W",
      },
      compatibility: {
        socket: "AM5",
        powerDraw: 120,
      },
    },
    {
      name: "Intel Core i5-14600K",
      category: "CPU",
      price: 18500,
      store: "Shopee",
      image: null,
      specs: {
        Cores: "14",
        Threads: "20",
        "Base Clock": "3.5 GHz",
        "Boost Clock": "5.3 GHz",
        TDP: "125W",
      },
      compatibility: {
        socket: "LGA1700",
        powerDraw: 181,
      },
    },

    // Motherboards
    {
      name: "ASUS ROG Strix X670E-E Gaming WiFi",
      category: "Motherboard",
      price: 28000,
      store: "PC Express",
      image: null,
      specs: {
        Socket: "AM5",
        Chipset: "X670E",
        "Memory Type": "DDR5",
        "Form Factor": "ATX",
        "Max Memory": "128GB",
      },
      compatibility: {
        socket: "AM5",
        memoryType: "DDR5",
        formFactor: "ATX",
      },
    },
    {
      name: "MSI MAG Z790 Tomahawk WiFi",
      category: "Motherboard",
      price: 24000,
      store: "EasyPC",
      image: null,
      specs: {
        Socket: "LGA1700",
        Chipset: "Z790",
        "Memory Type": "DDR5",
        "Form Factor": "ATX",
        "Max Memory": "192GB",
      },
      compatibility: {
        socket: "LGA1700",
        memoryType: "DDR5",
        formFactor: "ATX",
      },
    },
    {
      name: "Gigabyte B650 AORUS Elite AX",
      category: "Motherboard",
      price: 15500,
      store: "Lazada",
      image: null,
      specs: {
        Socket: "AM5",
        Chipset: "B650",
        "Memory Type": "DDR5",
        "Form Factor": "ATX",
        "Max Memory": "128GB",
      },
      compatibility: {
        socket: "AM5",
        memoryType: "DDR5",
        formFactor: "ATX",
      },
    },

    // GPUs
    {
      name: "NVIDIA GeForce RTX 4080 Super",
      category: "GPU",
      price: 65000,
      store: "Lazada",
      image: null,
      specs: {
        Memory: "16GB GDDR6X",
        "Boost Clock": "2.55 GHz",
        TDP: "320W",
        Interface: "PCIe 4.0",
        Outputs: "3x DP, 1x HDMI",
      },
      compatibility: {
        powerDraw: 320,
        interface: "PCIe 4.0",
      },
    },
    {
      name: "AMD Radeon RX 7900 XTX",
      category: "GPU",
      price: 58000,
      store: "PC Express",
      image: null,
      specs: {
        Memory: "24GB GDDR6",
        "Boost Clock": "2.5 GHz",
        TDP: "355W",
        Interface: "PCIe 4.0",
        Outputs: "2x DP, 2x HDMI",
      },
      compatibility: {
        powerDraw: 355,
        interface: "PCIe 4.0",
      },
    },
    {
      name: "NVIDIA GeForce RTX 4070 Ti",
      category: "GPU",
      price: 48000,
      store: "EasyPC",
      image: null,
      specs: {
        Memory: "12GB GDDR6X",
        "Boost Clock": "2.61 GHz",
        TDP: "285W",
        Interface: "PCIe 4.0",
        Outputs: "3x DP, 1x HDMI",
      },
      compatibility: {
        powerDraw: 285,
        interface: "PCIe 4.0",
      },
    },
    {
      name: "AMD Radeon RX 7800 XT",
      category: "GPU",
      price: 35000,
      store: "Shopee",
      image: null,
      specs: {
        Memory: "16GB GDDR6",
        "Boost Clock": "2.43 GHz",
        TDP: "263W",
        Interface: "PCIe 4.0",
        Outputs: "2x DP, 2x HDMI",
      },
      compatibility: {
        powerDraw: 263,
        interface: "PCIe 4.0",
      },
    },

    // RAM
    {
      name: "Corsair Vengeance DDR5 32GB (2x16GB) 6000MHz",
      category: "RAM",
      price: 8500,
      store: "Shopee",
      image: null,
      specs: {
        Capacity: "32GB (2x16GB)",
        Speed: "6000 MHz",
        Type: "DDR5",
        Latency: "CL36",
        Voltage: "1.35V",
      },
      compatibility: {
        memoryType: "DDR5",
        powerDraw: 10,
      },
    },
    {
      name: "G.Skill Trident Z5 RGB 32GB (2x16GB) 6400MHz",
      category: "RAM",
      price: 9800,
      store: "PC Express",
      image: null,
      specs: {
        Capacity: "32GB (2x16GB)",
        Speed: "6400 MHz",
        Type: "DDR5",
        Latency: "CL32",
        Voltage: "1.4V",
      },
      compatibility: {
        memoryType: "DDR5",
        powerDraw: 12,
      },
    },
    {
      name: "Kingston Fury Beast DDR5 32GB (2x16GB) 5200MHz",
      category: "RAM",
      price: 7200,
      store: "Lazada",
      image: null,
      specs: {
        Capacity: "32GB (2x16GB)",
        Speed: "5200 MHz",
        Type: "DDR5",
        Latency: "CL40",
        Voltage: "1.25V",
      },
      compatibility: {
        memoryType: "DDR5",
        powerDraw: 8,
      },
    },
    {
      name: "Corsair Vengeance DDR5 64GB (2x32GB) 5600MHz",
      category: "RAM",
      price: 15500,
      store: "EasyPC",
      image: null,
      specs: {
        Capacity: "64GB (2x32GB)",
        Speed: "5600 MHz",
        Type: "DDR5",
        Latency: "CL40",
        Voltage: "1.25V",
      },
      compatibility: {
        memoryType: "DDR5",
        powerDraw: 15,
      },
    },

    // Storage
    {
      name: "Samsung 990 Pro 2TB NVMe SSD",
      category: "Storage",
      price: 12500,
      store: "EasyPC",
      image: null,
      specs: {
        Capacity: "2TB",
        Interface: "NVMe PCIe 4.0",
        "Read Speed": "7450 MB/s",
        "Write Speed": "6900 MB/s",
        "Form Factor": "M.2 2280",
      },
      compatibility: {
        interface: "NVMe PCIe 4.0",
        powerDraw: 6,
      },
    },
    {
      name: "WD Black SN850X 1TB NVMe SSD",
      category: "Storage",
      price: 7500,
      store: "Lazada",
      image: null,
      specs: {
        Capacity: "1TB",
        Interface: "NVMe PCIe 4.0",
        "Read Speed": "7300 MB/s",
        "Write Speed": "6300 MB/s",
        "Form Factor": "M.2 2280",
      },
      compatibility: {
        interface: "NVMe PCIe 4.0",
        powerDraw: 5,
      },
    },
    {
      name: "Kingston KC3000 2TB NVMe SSD",
      category: "Storage",
      price: 10500,
      store: "Shopee",
      image: null,
      specs: {
        Capacity: "2TB",
        Interface: "NVMe PCIe 4.0",
        "Read Speed": "7000 MB/s",
        "Write Speed": "7000 MB/s",
        "Form Factor": "M.2 2280",
      },
      compatibility: {
        interface: "NVMe PCIe 4.0",
        powerDraw: 6,
      },
    },

    // PSUs
    {
      name: "Corsair RM850x 850W 80+ Gold Fully Modular",
      category: "PSU",
      price: 9500,
      store: "Lazada",
      image: null,
      specs: {
        Wattage: "850W",
        Efficiency: "80+ Gold",
        Modular: "Fully Modular",
        Warranty: "10 Years",
        "Form Factor": "ATX",
      },
      compatibility: {
        wattage: 850,
        formFactor: "ATX",
      },
    },
    {
      name: "Seasonic FOCUS GX-1000 1000W 80+ Gold",
      category: "PSU",
      price: 11500,
      store: "PC Express",
      image: null,
      specs: {
        Wattage: "1000W",
        Efficiency: "80+ Gold",
        Modular: "Fully Modular",
        Warranty: "10 Years",
        "Form Factor": "ATX",
      },
      compatibility: {
        wattage: 1000,
        formFactor: "ATX",
      },
    },
    {
      name: "EVGA SuperNOVA 750 GT 750W 80+ Gold",
      category: "PSU",
      price: 7800,
      store: "EasyPC",
      image: null,
      specs: {
        Wattage: "750W",
        Efficiency: "80+ Gold",
        Modular: "Fully Modular",
        Warranty: "7 Years",
        "Form Factor": "ATX",
      },
      compatibility: {
        wattage: 750,
        formFactor: "ATX",
      },
    },

    // Cases
    {
      name: "Lian Li O11 Dynamic EVO",
      category: "Case",
      price: 12000,
      store: "PC Express",
      image: null,
      specs: {
        "Form Factor": "ATX",
        "Max GPU Length": "420mm",
        "Max CPU Cooler": "167mm",
        "Fan Support": "10x 120mm",
        "Side Panel": "Tempered Glass",
      },
      compatibility: {
        formFactor: "ATX",
        maxGpuLength: 420,
      },
    },
    {
      name: "NZXT H510 Flow",
      category: "Case",
      price: 6500,
      store: "Lazada",
      image: null,
      specs: {
        "Form Factor": "ATX",
        "Max GPU Length": "365mm",
        "Max CPU Cooler": "165mm",
        "Fan Support": "7x 120mm",
        "Side Panel": "Tempered Glass",
      },
      compatibility: {
        formFactor: "ATX",
        maxGpuLength: 365,
      },
    },
    {
      name: "Fractal Design Torrent Compact",
      category: "Case",
      price: 9500,
      store: "Shopee",
      image: null,
      specs: {
        "Form Factor": "ATX",
        "Max GPU Length": "360mm",
        "Max CPU Cooler": "188mm",
        "Fan Support": "6x 140mm",
        "Side Panel": "Tempered Glass",
      },
      compatibility: {
        formFactor: "ATX",
        maxGpuLength: 360,
      },
    },

    // Cooling
    {
      name: "Noctua NH-D15 Chromax Black",
      category: "Cooling",
      price: 6500,
      store: "EasyPC",
      image: null,
      specs: {
        Type: "Air Cooler",
        Height: "165mm",
        "Fan Size": "2x 140mm",
        TDP: "250W",
        Sockets: "AM5, LGA1700",
      },
      compatibility: {
        powerDraw: 5,
      },
    },
    {
      name: "Corsair iCUE H150i Elite Capellix",
      category: "Cooling",
      price: 11500,
      store: "Lazada",
      image: null,
      specs: {
        Type: "AIO Liquid Cooler",
        "Radiator Size": "360mm",
        "Fan Size": "3x 120mm",
        TDP: "350W",
        Sockets: "AM5, LGA1700",
      },
      compatibility: {
        powerDraw: 15,
      },
    },
    {
      name: "Arctic Liquid Freezer II 280",
      category: "Cooling",
      price: 7800,
      store: "PC Express",
      image: null,
      specs: {
        Type: "AIO Liquid Cooler",
        "Radiator Size": "280mm",
        "Fan Size": "2x 140mm",
        TDP: "300W",
        Sockets: "AM5, LGA1700",
      },
      compatibility: {
        powerDraw: 10,
      },
    },
  ];

  // Add all parts to storage
  for (const part of parts) {
    // @ts-ignore - storage uses internal ID generation
    await (storage as any).parts.set(crypto.randomUUID(), { ...part, id: crypto.randomUUID() });
  }

  console.log(`Seeded ${parts.length} PC parts`);
}
