# PCFind - PC Parts Finder for the Philippines

## Overview

PCFind is a web application that helps users build custom PCs by browsing components from Philippine retailers (Lazada, Shopee, PC Express, EasyPC) with real-time compatibility checking. The platform provides a centralized hub for PC parts discovery, price comparison, and build validation - addressing the gap in existing marketplaces that lack specialized PC building features.

**Core Features:**
- Browse and search PC components from multiple Philippine retailers
- Real-time compatibility checking between parts (socket types, memory compatibility, power requirements)
- Interactive PC builder with build summary and compatibility scoring
- Save and manage multiple PC build configurations
- Responsive design with dark/light mode support

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling:**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and dev server with HMR support
- **Wouter** for lightweight client-side routing
- **TanStack Query** (React Query) for server state management and caching
- **Tailwind CSS** with custom design system based on shadcn/ui components

**Design System:**
- Custom theme extending shadcn/ui with "new-york" style preset
- Dark mode as default with light mode support via theme toggle
- Color palette inspired by ChatGPT interface (dark: 212 15% 12%, light: 0 0% 98%)
- Typography using Inter (body), Space Grotesk (headings), and JetBrains Mono (technical specs)
- Comprehensive UI component library in `client/src/components/ui/`

**State Management:**
- React Query for async server state with infinite stale time (no auto-refetch)
- Local component state for UI interactions
- Theme state persisted to localStorage

**Key Pages:**
- Home: Hero section with search and category navigation
- Browse Parts: Filterable catalog with grid/list views and sorting
- PC Builder: Interactive builder with part selection tabs and real-time compatibility
- Saved Builds: Manage and view saved configurations
- Help & About: Documentation and FAQ sections

### Backend Architecture

**Server Framework:**
- **Express.js** as the HTTP server
- **TypeScript** throughout for type safety
- Development and production build scripts with esbuild bundling
- Custom request logging middleware for API routes

**API Design:**
- RESTful endpoints under `/api` namespace
- Routes defined in `server/routes.ts`
- Key endpoints:
  - `GET /api/parts` - Retrieve all parts
  - `GET /api/parts/:category` - Filter by category
  - `POST /api/compatibility/check` - Validate part combinations
  - `GET /api/builds` - Retrieve saved builds
  - `POST /api/builds` - Create new build

**Data Storage Strategy:**
- In-memory storage implementation (`MemStorage` class) for development
- Interface-based storage abstraction (`IStorage`) allowing future database implementation
- Data seeding on server startup with Philippine-market PC parts

**Compatibility Logic:**
- Socket matching (CPU/Motherboard - AM5, LGA1700, etc.)
- Memory type validation (DDR4/DDR5)
- Power calculation and PSU capacity checking
- Form factor compatibility (Case/Motherboard)
- Scoring system (0-100) with detailed issue reporting

### Data Schema

**Database Configuration:**
- Configured for PostgreSQL via Drizzle ORM (currently not active)
- Schema defined in `shared/schema.ts` with Zod validation
- Neon serverless PostgreSQL in dependencies

**Core Entities:**

**Parts Table:**
- ID (UUID), name, category, price, store
- Specs (JSONB) - flexible key-value pairs for technical specifications
- Compatibility (JSONB) - socket, memoryType, powerDraw, formFactor, interface, wattage, maxGpuLength

**Builds Table:**
- ID (UUID), name, partIds (array), totalCost, compatibilityScore, createdAt

**Categories:**
- CPU, GPU, RAM, Motherboard, Storage, PSU, Case, Cooling

### External Dependencies

**Third-Party UI Libraries:**
- **Radix UI** - Headless component primitives for accessibility (accordion, dialog, dropdown, popover, etc.)
- **shadcn/ui** - Pre-built component system built on Radix
- **cmdk** - Command palette component
- **Embla Carousel** - Carousel/slider functionality
- **Lucide React** - Icon library

**Data & State:**
- **TanStack Query v5** - Server state management with caching
- **React Hook Form** with Zod resolvers for form validation
- **date-fns** - Date formatting utilities

**Database (Configured but Not Active):**
- **Drizzle ORM** - Type-safe SQL query builder
- **@neondatabase/serverless** - Serverless Postgres driver
- **Drizzle-Zod** - Schema to Zod validator conversion
- PostgreSQL connection via `DATABASE_URL` environment variable

**Development Tools:**
- **@replit/vite-plugin-runtime-error-modal** - Enhanced error overlay
- **@replit/vite-plugin-cartographer** - Code navigation
- **tsx** - TypeScript execution for dev server
- **esbuild** - Fast bundling for production

**Styling:**
- **Tailwind CSS** with PostCSS and Autoprefixer
- **class-variance-authority** - Component variant management
- **tailwind-merge** & **clsx** - Conditional class composition

**Note on Database:**
The application is configured to use PostgreSQL with Drizzle ORM (migrations directory exists, schema defined), but currently uses in-memory storage. The database can be activated by:
1. Provisioning a PostgreSQL instance (Neon or other)
2. Setting `DATABASE_URL` environment variable
3. Running `npm run db:push` to sync schema
4. Switching from `MemStorage` to a database-backed implementation