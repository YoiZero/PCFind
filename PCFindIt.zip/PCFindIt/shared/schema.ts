import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// PC Parts table
export const parts = pgTable("parts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(), // CPU, GPU, RAM, Motherboard, Storage, PSU, Case, Cooling
  price: integer("price").notNull(),
  store: text("store").notNull(), // Lazada, Shopee, PC Express, EasyPC
  image: text("image"),
  specs: jsonb("specs").notNull().$type<Record<string, string>>(), // Flexible specs object
  compatibility: jsonb("compatibility").notNull().$type<{
    socket?: string; // CPU/Motherboard socket
    memoryType?: string; // DDR4/DDR5
    powerDraw?: number; // Watts
    formFactor?: string; // ATX, Mini-ITX, etc
    interface?: string; // PCIe, M.2, etc
    wattage?: number; // PSU wattage
    maxGpuLength?: number; // Case clearance in mm
  }>(),
});

// Saved PC Builds table
export const builds = pgTable("builds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  partIds: text("part_ids").array().notNull(), // Array of part IDs
  totalCost: integer("total_cost").notNull(),
  compatibilityScore: integer("compatibility_score").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Schemas and types for parts
export const insertPartSchema = createInsertSchema(parts).omit({
  id: true,
});

export type InsertPart = z.infer<typeof insertPartSchema>;
export type Part = typeof parts.$inferSelect;

// Schemas and types for builds
export const insertBuildSchema = createInsertSchema(builds).omit({
  id: true,
  createdAt: true,
});

export type InsertBuild = z.infer<typeof insertBuildSchema>;
export type Build = typeof builds.$inferSelect;
