# PCFind - Design Guidelines

## Design Approach: Reference-Based with ChatGPT Inspiration

**Selected Reference**: ChatGPT interface for core search/interaction patterns, combined with Linear's clean typography and Notion's content organization for parts catalog.

**Justification**: PCFind is a utility-focused tool where efficiency and clarity are paramount. The ChatGPT-style interface provides familiar, intuitive interaction patterns perfect for the search-driven PC parts finder. This approach balances approachability for beginners with the technical precision intermediate builders need.

**Key Design Principles**:
- Simplicity first: Remove cognitive load for technical decisions
- Search-centric: Make finding and filtering parts effortless
- Clarity over decoration: Technical specs must be scannable
- Progressive disclosure: Show complexity only when needed

## Core Design Elements

### A. Color Palette

**Dark Mode Primary** (default):
- Background: 212 15% 12% (deep charcoal)
- Surface: 215 20% 16% (elevated panels)
- Surface Accent: 215 25% 20% (hover states, borders)
- Text Primary: 0 0% 95% (high contrast)
- Text Secondary: 0 0% 65% (labels, metadata)

**Light Mode**:
- Background: 0 0% 98% (soft white)
- Surface: 0 0% 100% (pure white cards)
- Surface Accent: 220 15% 94% (subtle borders)
- Text Primary: 215 25% 15% (dark charcoal)
- Text Secondary: 215 15% 45% (muted text)

**Brand & Interactive Colors**:
- Primary: 210 90% 55% (trust blue - compatibility checks, CTAs)
- Success: 142 70% 45% (compatible parts indicator)
- Warning: 38 95% 55% (compatibility warnings)
- Error: 0 85% 60% (incompatible parts alerts)
- Accent: 265 75% 60% (premium features, highlights)

### B. Typography

**Font Families**:
- Primary: 'Inter' (body text, UI elements, technical specs)
- Display: 'Space Grotesk' (headings, part names, build titles)
- Mono: 'JetBrains Mono' (technical specifications, socket types, codes)

**Type Scale**:
- Hero/Display: text-5xl font-bold (part category headers)
- H1: text-3xl font-semibold (section titles)
- H2: text-2xl font-medium (card headers, part names)
- H3: text-xl font-medium (subsections)
- Body: text-base font-normal (descriptions, general content)
- Small: text-sm (metadata, labels, helper text)
- Tiny: text-xs (tags, badges, fine print)

### C. Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16, 20** for consistent rhythm.
- Component padding: p-4 to p-6
- Section gaps: gap-8 to gap-12
- Page margins: mx-4 md:mx-8 lg:mx-16
- Card spacing: p-6 to p-8
- Element gaps: gap-2 to gap-4

**Container Strategy**:
- Max width: max-w-7xl for main content
- Search interface: max-w-4xl centered
- Parts grid: full width with responsive columns
- Build summary: max-w-2xl sidebar

**Grid Patterns**:
- Parts catalog: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
- Build components: grid-cols-1 lg:grid-cols-2 (part selector + build preview)
- Compatibility cards: grid-cols-1 md:grid-cols-2

### D. Component Library

**Navigation Bar**:
- Fixed top position with backdrop blur
- Horizontal layout: Logo left, nav items center, actions right
- Items: Home, Browse Parts, PC Builder, Saved Builds, Help, About
- Mobile: Hamburger menu with slide-in drawer
- Height: h-16 with px-6 padding

**ChatGPT-Style Search Interface**:
- Centered on homepage with max-w-4xl
- Large search input: h-14 with rounded-2xl border
- Placeholder: "Ask me anything about PC building or search for parts..."
- Autocomplete dropdown showing part suggestions and categories
- Voice search icon (optional enhancement)

**Parts Cards**:
- White/dark surface with rounded-xl border
- Image top: aspect-video with object-cover
- Part name: text-lg font-semibold
- Key specs: grid layout with icon + value pairs
- Price: text-2xl font-bold with currency
- Store badge: Small pill showing source (Lazada/Shopee/Physical)
- Add to Build button: Primary color, full width bottom

**Compatibility Checker Panel**:
- Sticky sidebar or collapsible panel
- Color-coded status indicators (green/yellow/red)
- Expandable conflict details with technical explanations
- Power consumption calculator with visual bar
- Socket/chipset compatibility matrix

**Build Summary Card**:
- Elevated surface with shadow-lg
- Total cost: Large, prominent display
- Parts list: Compact rows with thumbnail + name + price
- Compatibility score: Circular progress indicator
- Action buttons: Save Build, Share, Export to PDF

**Modal Dialogs**:
- Overlay: backdrop-blur-sm with bg-black/50
- Content: max-w-2xl centered with rounded-xl
- Close button: top-right with hover:bg-accent
- Usage: Part details, compatibility warnings, save build

**Data Display**:
- Specification tables: Striped rows with hover states
- Comparison view: Side-by-side columns for 2-3 parts
- Filter chips: Rounded-full pills with remove icon
- Sort dropdown: Minimal with chevron icon

### E. Animations

Use sparingly for functional feedback only:
- Search input: Subtle scale on focus (scale-105)
- Card hover: translate-y-1 with shadow increase
- Compatibility status: Fade-in alerts (duration-300)
- NO scroll animations, parallax, or decorative motion

## Images

**Hero Section Image**: 
- Full-width hero with gaming PC build showcase
- Image description: "Premium RGB gaming PC with visible components - GPU, cooling system, motherboard - professional product photography with dramatic lighting"
- Placement: Top of homepage, h-[60vh] with overlay gradient
- Treatment: Dark gradient overlay (from-black/60 to-transparent) for text readability

**Parts Catalog Images**:
- High-quality product photos on white/transparent backgrounds
- Consistent aspect ratio (4:3 or 1:1)
- Show actual product, not lifestyle shots
- Fallback: Component category icon if image unavailable

**Compatibility Visualization**:
- Diagram/illustration showing PC component connections
- Placement: Help section and compatibility checker
- Description: "Simplified motherboard diagram highlighting CPU socket, RAM slots, PCIe lanes, and power connectors"

**Store Badges/Logos**:
- Small circular store logos (Lazada, Shopee, physical stores)
- Size: w-8 h-8 or w-6 h-6 depending on context

## Page-Specific Guidelines

**Homepage**:
- Hero with search bar centered vertically
- Quick category cards below (CPU, GPU, RAM, etc.) - 6 cards in grid
- Featured builds section showing 3 popular configurations
- How it works: 3-step process illustration
- Footer with links and newsletter signup

**Browse Parts Page**:
- Sidebar filters (left): Category, price range, brand, specs
- Main grid (right): Parts cards in responsive grid
- Top bar: Search, sort dropdown, view toggle (grid/list)
- Pagination or infinite scroll

**PC Builder Page**:
- Two-column layout: Part selector (left) + Build preview (right)
- Compatibility panel always visible
- Progressive build flow: CPU → Motherboard → RAM → GPU → Storage → PSU → Case
- Build summary sticky on scroll

**Saved Builds Page**:
- Grid of saved build cards
- Each card: Thumbnail, name, total cost, date, compatibility status
- Actions: View, Edit, Delete, Share
- Empty state: Illustration with CTA to create first build

This design framework creates a professional, user-friendly experience that makes PC building accessible to beginners while providing the precision intermediate builders need.